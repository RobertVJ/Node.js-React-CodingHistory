// archivo ts typescript
var Tienda = /** @class */ (function () {
    function Tienda(n) {
        this.name = n;
    }
    Tienda.prototype.describe = function () {
        console.log("Mi tienda se llama" + this.name);
    };
    return Tienda;
}());
var tiendita = new Tienda("Gomitas y  mas");
console.log(tiendita);
tiendita.describe();
