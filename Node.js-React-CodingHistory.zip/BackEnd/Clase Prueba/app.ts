import  "amazon-connect-streams";


connect.core.initCCP({
   
});
