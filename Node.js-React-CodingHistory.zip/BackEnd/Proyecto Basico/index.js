// para usar el dotenv es asi:
const dotenv = require('dotenv');
dotenv.config();
const port = process.env.PORT;

console.log(`corriendo en el puerto: ${port}`);