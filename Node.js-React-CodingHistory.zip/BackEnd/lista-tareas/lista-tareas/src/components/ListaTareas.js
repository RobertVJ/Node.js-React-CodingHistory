// Autor: Roberto Valdez
// Encapsula la forma de captura y los renglones de las tareas. 

import { Fragment, useState } from "react";
import CapturaTarea from "./CapturaTarea";
import Tarea from "./Tarea";


const ListaTareas = (props) => { 
    // Arreglo de objetos (tareas)
    const [arrTareas, setArrTareas] = useState([]);

    //Agrega una tarea nueva, se ejecuta desde el hijo (capturaTarea)
    const agregarTarea = (nuevaTarea) => {
        if(nuevaTarea.texto.trim().length > 0){
            const arrTareasNuevo = [nuevaTarea, ...arrTareas]; //... -> operador, me da lista de objetos que tiene el arreglo uno por uno
            setArrTareas(arrTareasNuevo);
        }
        setEstaCapturando(false);
    };

    const completarTarea = (id) => {
        const arrTareasNuevo = arrTareas.map((tarea) => {
            if (tarea.id == id) {
                tarea.completada =!tarea.completada;
            }
            return tarea;
        })
        setArrTareas(arrTareasNuevo);
    };
    // Clase para eliminar las tareas
    const eliminarTarea = (id) =>{
        const arrTareaNuevo = arrTareas.filter(
            (tarea) => tarea.id !==id
            );
        setArrTareas(arrTareaNuevo);
    }

    const [estaCapturado, setEstaCapturando] = useState(false);

    const iniciarCaptura = () => {
        setEstaCapturando(true);
    }

    const terminarCaptura = () => {
        setEstaCapturando(false);
    }
    return (
        <Fragment>
            {estaCapturado && <CapturaTarea onSubmit = {agregarTarea} onCancel = {terminarCaptura}
            />}
            {!estaCapturado && <button onClick={iniciarCaptura}>Capturar</button>}
            <div className="lista-tareas-contenedor">
                {
                    //Se utilizan () en lugar de {}, ya que con las llaves se tendría que poner return(tareas), con () soo tarea
                    arrTareas.map( (tarea) => (
                        <Tarea texto={tarea.texto} completada={tarea.completada} 
                        completarTarea={completarTarea} 
                        eliminarTarea  = {eliminarTarea}
                        id={tarea.id} />
                    ))
                }
                {
                    
                    arrTareas.length === 0 && <h1>No hay Tareas</h1> 
                }
            </div>
        </Fragment>
    )
 };

 export default ListaTareas;

 //En lugar de Fragment, se puede dejar la etiqueta vacía, con el fin de no usar div. 