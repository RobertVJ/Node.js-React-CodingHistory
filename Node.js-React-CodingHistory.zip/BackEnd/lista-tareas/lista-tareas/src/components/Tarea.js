// Autor: Roberto Valdez
// Renglón que representa una tarea.

import {MdOutlineDeleteForever} from "react-icons/md";
import "../styles/Tarea.css";

const Tarea = (props) => {

    // Funcion Local
    const completarTarea = () =>{
        props.completarTarea(props.id)
    }

    const estilo = "tarea-contenedor" + (props.completada ? " completada" : ""); 
    return (
        <div className={estilo}>
            <div className="tarea-texto" onClick={completarTarea}>
                {props.texto}
            </div>
            <div className="tarea-contenedor-icono"
             onClick={() => props.eliminarTarea(props.id)}>
                <MdOutlineDeleteForever />
            </div>
        </div>
    );
 };

export default Tarea;