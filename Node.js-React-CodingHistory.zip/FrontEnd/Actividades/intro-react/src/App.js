/* App que nos apoya a generar la aplicacion en la web (localhost) */
// Autor:Roberto Valdez Jasso
//Fecha: 05/04/2022
// Matricula A01746863

// Importes:
import './App.css';
import Datosvideo from "./components/Datosvideo";

function App() {
  // Arreglo de Info
  const arrVideo =[
    {
      // datos del objecto 1
      foto: "IGP",
      texto: "DUDE.. Everyone Forgot About This Game?! Thet Made It 10000x MORE TERIFFYING",
      autor: "IGP",
      vistas: "81,180 vistas"
    },
    {
      // datos del objecto 2
      foto: "StarWars",
      texto: "10 Minutes of LEGO Star Wars: The Skywalker Saga Gameplay",
      autor: "GameSpot",
      vistas: "15,068 vistas"
    },
    {
      // datos del objecto 3
      foto: "music",
      texto: "Michael Calfal - Blinded By The Lights (ft. IMAN)",
      autor: "Nightblue Music",
      vistas: "15,668 vistas"
    },
    {
      // datos del objecto 4
      foto: "gta",
      texto: "This race is IMPOSSIBLE | GTA 5",
      autor: "YOGSCAST Lewis & Simon",
      vistas: "87,087 vistas"
    },
    {
      // datos del objecto 5
      foto: "GeeksofGeeks",
      texto: "How to build a faster landing Page | GeekSummerCarnival",
      autor: "GeeksforGeeks",
      vistas: "2,391 vistas"
    }
  ]
  // regreso de la activacion de la app
  return(
    <div className='App'>
      {
        arrVideo.map(
          (video) => (
            <Datosvideo datos ={video} />
          )
        )
      }
    </div>
  )
}

export default App;
