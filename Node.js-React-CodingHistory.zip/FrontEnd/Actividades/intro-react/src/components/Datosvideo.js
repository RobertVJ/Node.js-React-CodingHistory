/* Linea con info del video clonado de Youtube */
// Autor:Roberto Valdez Jasso
//Fecha: 05/04/2022
// Matricula A01746863

// Importes:
import Titulo from "./Tituto"
import "../styles/VideoLinea.css"
import "../styles/Imagen.css"



// Componente Datosideo
const VideoLinea = (props) => {
    //regresamos la linea completa
    return(
        <div className="contenedor-video">
            <div className="imagen-video">
            <img src= {require(`../images/${props.datos.foto}.PNG`)} alt= "foto" />
            </div>
            <Titulo texto = {props.datos.texto} />
            <div className="autor">
                Autor: {props.datos.autor}
            </div>
            <div className="vistas">
                Vista: {props.datos.vistas}
            </div>            
        </div>
    );
};
// exportamos
export default VideoLinea;