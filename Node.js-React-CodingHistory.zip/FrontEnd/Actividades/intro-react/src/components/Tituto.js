/* Titulo del video clonado de Youtube */
// Autor:Roberto Valdez Jasso
//Fecha: 05/04/2022
// Matricula A01746863

// Importes
import "../styles/Titulo.css"

// Componente Titulo:
const Titulo = (props) =>{
    // Regresamos el titulo
    return(
        <div className="titulo-video">
            <p>{props.texto}</p>
        </div>
    );
};
//Exportamos
export default Titulo;