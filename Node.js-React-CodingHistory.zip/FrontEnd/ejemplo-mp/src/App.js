/*
Autor: Roberto Valdez Jasso
Co Autor: Roberto Roman
Descripcion:
Codigo que incluye todos los elementos que la aplicacion necesita 
usar para que  optima funcion.
*/ 

// Importes
import { Routes, Route } from 'react-router-dom';
// Estilos
import { About, Contact, Events, History, Home, NotFound, Products, Services } from './Components/Pages';
import Menu from './Components/Menu';
import './Styles/App.css';

function App() {
  return (
    <div className="App"> 
      <Menu />
      <div class="linea"></div>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/about' element={<About />} >
          <Route path='services' element={<Services />} />
          <Route path='history' element={<History />} />
        </Route>
        <Route path='/products' element={<Products />} />
        <Route path='/events' element={<Events />} />
        <Route path='/contacts' element={<Contact />} /> 
        <Route path='*' element={<NotFound />} />
      </Routes>
      
    </div>
  );
}

export default App;
