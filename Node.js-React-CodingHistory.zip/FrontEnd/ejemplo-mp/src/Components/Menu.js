/*
Autor: Roberto Valdez Jasso
Co Autor: Roberto Roman
Descripcion
Elemento Menu que nos apoya que el menu sea fijo siendo un componentete (pieza) independiente a lo demas.
*/ 
import { Link } from "react-router-dom";

export default function Menu() {
  return (
    <div>
        <h1>Tecnológico de Monterrey</h1>
        <nav>
            <Link to="about" className="acerca">Acerca de</Link>
            <Link to="products" className="products">Productos</Link>
            <Link to="events" className="events">Eventos</Link>
            <Link to="contacts" className="contacts ">Contacto</Link>
        </nav>
    </div>
    )
}