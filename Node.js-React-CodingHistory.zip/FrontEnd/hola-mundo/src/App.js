import './App.css';
// Importes
//import GanadorOscar from './components/Ganador';
import GanadorOscar from './components/Ganadordatos';

function App() {

  // Arreglos (informacion de la app)
  // Arreglo independiente
  const arrOscares = [
    {
      //Datos del objecto
      texto: "Mejor Pelicula Animada",
      ganador: "Encanto",
      nominados: "a, b, c, d , y los demas",
      foto: "Encanto"
    },
    {
      texto: "Mejor actor",
      ganador: "Will Smith",
      nominados: "x, y, z , y los demas",
      foto: "Will_Smith"

    }
  ]

  // regreso de la aplicaciion
  /*
  return (
    <div className='App'>
      {
        // expresion de javascript
        arrOscares.map(
          (oscar) =>(
            <GanadorOscar texto={oscar.texto} 
            ganador={oscar.ganador}
            nominados={oscar.nominados}
            foto={oscar.foto} 
            />
          )

        )
      }

    </div>  
  );*/

  return(
    <div className='App'>
      {
        arrOscares.map(
          (oscar) => (
            <GanadorOscar datos= {oscar} />
          )
        )
      }
    </div>
  )
}
export default App;
