/*Renglon Completo de la lista de ganadores */
// Autor: Roberto Valdez Jasso
// Matricula: A01746863

import Titulo from "./Titulo";
import "../styles/GanadorOscar.css"

// Definicon del componente
const GanadorOscar = (props) => {
  // regresamos el componente texto ganador
  return (
  <div className="contenedor-oscar">
    <Titulo texto ={props.texto}/>
    <div className="ganador_oscar">
      Ganador:<b>{props.ganador}</b>
    </div>
    <div className="nominados-oscar">
      Nominados: {props.nominados}
    </div>
    <img src={require(`../images/${props.foto}.jpg`)} alt="Foto"/>


  </div>)
  ;
};
// Exportamos
export default GanadorOscar;
