/*Renglon Completo de la lista de ganadores */
// Autor: Roberto Valdez Jasso
// Matricula: A01746863

import Titulo from "./Titulo";
import "../styles/GanadorOscar.css"

// Definicon del componente
const GanadorOscar = (props) => {
  // regresamos el componente texto ganador
  return (
  <div className="contenedor-oscar">
    <Titulo texto ={props.datos.texto}/>
    <div className="ganador_oscar">
      Ganador:<b>{props.datos.ganador}</b>
    </div>
    <div className="nominados-oscar">
      Nominados: {props.datos.nominados}
    </div>
    <img src={require(`../images/${props.datos.foto}.jpg`)} alt="Foto"/>


  </div>)
  ;
};
// Exportamos
export default GanadorOscar;