import "../styles/Titulo.css"
// Generamos el componente titulo
const Titulo = (props) =>{
    // Regrsamos el letrero
    return(
       <div className="titulo-oscar">
           <p>{props.texto}</p>
       </div>
        
    );

};
// Exportamos
export default Titulo;