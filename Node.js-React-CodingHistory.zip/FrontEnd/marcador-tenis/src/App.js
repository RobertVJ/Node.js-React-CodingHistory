import './App.css';
import Puntos from './components/Puntos';
import Titulo from './components/Titulo';
import Boton from './components/Boton';
import { useState } from 'react';

function App() {
  // Estado de los puntos de los jugadores
 const [puntosA, setPuntosA] = useState(0);
 const [puntosB, setPuntosB] = useState(0);

 // Funciones handlers para los botones
 // Boton A
 const botonAHandler = (event) =>{
   if(puntosA < 30){
      setPuntosA(puntosA + 15); // ASINCRONO / se ejecuta en 
                                //  otro thread para que
                                // el main realice los demas 
                                //procesos
   } 
   if(puntosA == 30){
    setPuntosA(puntosA + 10); 
  } 
   if((puntosA == 40 || puntosA =="AD") && (puntosB == 40 || puntosB =="AD")){
    setPuntosA(30);
    setPuntosB(30);
   }

   if(puntosA == 30 && puntosB == 30 ){
     setPuntosA("AD")
   }
   if((puntosA == "AD" || puntosA == 40) &&  (puntosB > 0  && puntosB < 40) ){
      botonReserHandler()
   }
   
 };

  // Boton B
  const botonBHandler = (event) =>{
    if(puntosB < 30){
      setPuntosB(puntosB + 15); // ASINCRONO / se ejecuta en 
                           //  otro thread para que
                           // el main realice los demas 
                           //procesos
    } 
    if(puntosB == 30){
      setPuntosB(puntosB + 10);
    }
    if((puntosB == 40 || puntosB =="AD") && (puntosA == 40 || puntosA =="AD")){
      setPuntosA(30);
      setPuntosB(30);
     }
    if(puntosB == 30 && puntosA == 30 ){
      setPuntosB("AD")
    }
    
    if((puntosB == "AD" || puntosB == 40) &&  (puntosA > 0  && puntosA < 40)){
      botonReserHandler()
   }
  };

   // Boton B
   const botonReserHandler = (event) =>{
    setPuntosA(0);
    setPuntosB(0) 
  };;

  return (
    <div className="App">
      <Titulo texto = "Jugador A" />
      <Puntos valor={puntosA} /> 
      <Titulo texto = "Jugador B" />
      <Puntos valor={puntosB} /> 
      <Boton texto = "Gana A" onClick ={botonAHandler} />
      <Boton texto = "Gana B" onClick ={botonBHandler}/>
      <Boton texto = "RESET" onClick ={botonReserHandler}/>
    </div>
  );
}

export default App;
