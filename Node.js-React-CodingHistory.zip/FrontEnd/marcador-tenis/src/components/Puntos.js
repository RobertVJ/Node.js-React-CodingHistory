/* 
Autor: 
    Roberto Valdez Jasso
 Proposito:
    Recuento de puntos por cada jugador de tennis */

    // Importes
import "../styles/Puntos.css"

const Puntos = (props) =>{
    return(
        <div className="puntos-tennis">
            {props.valor}
        </div>
    );

};
export default Puntos