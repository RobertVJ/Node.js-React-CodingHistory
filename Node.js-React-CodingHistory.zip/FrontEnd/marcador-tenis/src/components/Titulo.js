/* 
Autor: 
    Roberto Valdez Jasso
 Proposito:
    Titulo de los puntos de jugadores de tennis */


// Importes
import "../styles/Titulo.css"

const Titulo = (props) => {
  return(
    <div className="titulo-tennis">
       {props.texto}
    </div>
  );  
};
export default Titulo;
