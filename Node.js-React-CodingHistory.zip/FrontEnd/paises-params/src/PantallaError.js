import "./styles/PantallaError.css";

const PantallaError = () => {
    return(
        <div className="overlay">
            <h1>Error el Pais no existe</h1>
        </div>

    );
};

export default PantallaError;