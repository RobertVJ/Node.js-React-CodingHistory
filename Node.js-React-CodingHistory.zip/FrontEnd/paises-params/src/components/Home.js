// Componente Home

import { useNavigate } from "react-router-dom";
import { useRef} from "react";


const Home =  () => {

    const nombrePais = useRef("");
    const navegar = useNavigate();
    const consultar = (event)=>{
        event.preventDefault();
        navegar("/" + nombrePais.current.value);
    };

    return(
        <div>
            <form>
                <input type= "text" placeholder="Teclea un Pais"  ref={nombrePais}/>
                <button type="default" onClick={consultar}>Consultar</button>
            </form>
        </div>
    );

};

export default Home;