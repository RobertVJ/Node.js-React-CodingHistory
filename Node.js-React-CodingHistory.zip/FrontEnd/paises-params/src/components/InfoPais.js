import { useParams } from "react-router-dom";
import { useState, useEffect} from "react";
import PantallaError from "../PantallaError";

const InfoPais = () => { 
    const { nombrePais } = useParams();
    const [url,setUrl] = useState("");
    const [error , setError] = useState(false);

    useEffect(() => {
        fetch("https://restcountries.com/v3.1/name/"+ nombrePais)
        .then(response => response.json())
        .then(data =>{
            if(data[0] == undefined){
                setError(true);
            }else{
                const url = data[0].flags.png;
                setUrl(url);
            }
           
        })
        .catch(error => console.log(error))
    });

    return (
        <div>
            <h1>{nombrePais}</h1>
            <img src={url} alt = ""/>
            {error  && <PantallaError/>}
        </div>
    );
 };

 export default InfoPais;