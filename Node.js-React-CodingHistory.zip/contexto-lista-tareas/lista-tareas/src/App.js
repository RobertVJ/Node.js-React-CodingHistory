//Autor: Renata de Luna
// Administra una lista de tareas

import { useEffect } from "react";
import "./App.css";
import ListaTareas from "./components/ListaTareas";
import ProveedorTareas from "./components/ProveedorTareas";

function App() {

  useEffect(()=> {
    console.log("Inicia la aplicacion en APP")
  });


  return (
    <ProveedorTareas>
      <div className="App">
        <ListaTareas />
      </div>
    </ProveedorTareas>
  );
}

export default App;
