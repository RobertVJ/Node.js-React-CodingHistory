// Autor: Roberto Valdez
// Forma para capturar una nueva tarea. 

import { useContext, useState } from "react";
import "../styles/CapturaTarea.css";
import { v4 as uuidv4 } from 'uuid';
import { ContextoTarea } from "./ProveedorTareas";


const CapturaTarea = (props) => { 
    // CONTEXTO. para tener acceso a arrtareas definido en el contexto
    const [,agregarTarea] = useContext(ContextoTarea);

    //El valor del input se guarda en el estado del componente. 
    const [descripcionTarea, setDescripcionTarea] = useState("");

    //Atiende el evento de cambio en el imput (onChange)
    const cambioEntradaHandler = (event) => {
      setDescripcionTarea(event.target.value);
      console.log(descripcionTarea);
    };

    //Atiende el click del botón (Agregar tarea)
    const agregarTareaHandler = (event) => {
      event.preventDefault(); //Evita que se recargue la página y así no se pierde el estado. 
      const tareNueva = {
        id: uuidv4(),
        texto: descripcionTarea, //No se ponen llaves porque es JS y no JSX
        completada: false
      };
      agregarTarea(tareNueva);
      props.onCancel();
    };

    return(
        <form className="tarea-forma">
            <input className="tarea-input"
            type="text"
            placeholder="Escribe una nueva tarea"
            name="texto" 
            onChange={cambioEntradaHandler} />
            <button className="tarea-boton" onClick={agregarTareaHandler}>Agregar tarea</button>
            <button onClick={() => props.onCancel()}>Cancelar</button>
        </form>
    );
 };

 export default CapturaTarea;