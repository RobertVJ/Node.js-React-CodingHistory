// Autor: Roberto Valdez
// Encapsula la forma de captura y los renglones de las tareas.

import { useContext } from "react";
import { Fragment, useState } from "react";
import CapturaTarea from "./CapturaTarea";
import { ContextoTarea } from "./ProveedorTareas";
import Tarea from "./Tarea";

const ListaTareas = (props) => {
  // CONTEXTO
  // ARREGLO DE TAREAS
  const [arrTareas] = useContext(ContextoTarea);

  const [estaCapturado, setEstaCapturando] = useState(false);

  const iniciarCaptura = () => {
    setEstaCapturando(true);
  };

  const terminarCaptura = () => {
    setEstaCapturando(false);
  };

  return (
    <Fragment>
      {estaCapturado && <CapturaTarea onCancel={terminarCaptura} />}
      {!estaCapturado && <button onClick={iniciarCaptura}>Capturar</button>}
      <div className="lista-tareas-contenedor">
        {
          //Se utilizan () en lugar de {}, ya que con las llaves se tendría que poner return(tareas), con () soo tarea
          arrTareas.map((tarea) => (
            <Tarea
              texto={tarea.texto}
              completada={tarea.completada}
              id={tarea.id}
            />
          ))
        }
        {arrTareas.length === 0 && <h1>No hay Tareas</h1>}
      </div>
    </Fragment>
  );
};

export default ListaTareas;

//En lugar de Fragment, se puede dejar la etiqueta vacía, con el fin de no usar div.
