/*
AUTOR: Roberto Valdez Jasso
Encapsula el arreglo de tareaas y las operaciones sobre el arreglo
*/

import { createContext, useState } from "react";

// Crea el contexto  'global'
export const ContextoTarea = createContext();

const ProveedorTareas = ({children}) => {
    // estado arreglo de tareas
    const [arrTareas, setArrTareas] = useState([]);
    //Metodos
    //Agregar
    const agregarTarea = (tarea) => {
        setArrTareas([tarea, ...arrTareas]);
    };
    //Completar
    const completarTarea = (id) => {
        const arrTareasNuevo = arrTareas.map((tarea) => {
          if (tarea.id === id) {
            tarea.completada = !tarea.completada;
          }
          return tarea;
        });
        setArrTareas(arrTareasNuevo);
    };
    // Eliminar
    const eliminarTarea = (id) => {
        const arrTareaNuevo = arrTareas.filter((tarea) => tarea.id !== id);
        setArrTareas(arrTareaNuevo);
      };

    return (
        <ContextoTarea.Provider value={[arrTareas, agregarTarea, completarTarea,eliminarTarea]}>
            {children}
        </ContextoTarea.Provider>
    );
 };

export default ProveedorTareas