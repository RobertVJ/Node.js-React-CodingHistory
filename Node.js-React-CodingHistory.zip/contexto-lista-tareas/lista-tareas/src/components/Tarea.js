// Autor: Roberto Valdez
// Renglón que representa una tarea.

import { useContext, useEffect } from "react";
import {MdOutlineDeleteForever} from "react-icons/md";
import "../styles/Tarea.css";
import { ContextoTarea } from "./ProveedorTareas";

const Tarea = (props) => {

    useEffect(()=>{
        console.log("Dibujando una tarea (Tarea)");
    });
    

    // CONTEXTO
    const [, , completarTarea, eliminarTarea] = useContext(ContextoTarea);



    const estilo = "tarea-contenedor" + (props.completada ? " completada" : ""); 
    return (
        <div className={estilo}>
            <div className="tarea-texto" onClick={() => completarTarea(props.id)}>
                {props.texto}
            </div>
            <div className="tarea-contenedor-icono"
             onClick={() => eliminarTarea(props.id)}>
                <MdOutlineDeleteForever />
            </div>
        </div>
    );
 };

export default Tarea;